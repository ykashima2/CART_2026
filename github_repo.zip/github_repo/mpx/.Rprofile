# Use the shared renv project in the root directory
if (file.exists("../renv/activate.R")) source("../renv/activate.R")
